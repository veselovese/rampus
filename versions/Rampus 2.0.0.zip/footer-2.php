<footer>
    <div>
        <p>Rampus (Рампус), 2024</p>
        <p>Версия 2.0.0</p>
    </div>
    <a href="https://t.me/rampusru" target="_blank"><img src="../pics/TelegramIcon.svg" alt="Официальный telegram-канал"></a>
</footer>